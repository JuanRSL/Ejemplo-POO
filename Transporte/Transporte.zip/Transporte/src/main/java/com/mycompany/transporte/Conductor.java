package com.mycompany.transporte;

public class Conductor extends Persona {
    int Licencia;
    public Conductor(String Nombres, int ID, int Licencia) {
        super(Nombres, ID);
        this.Licencia = Licencia;
    }

    public int getLicencia() {
        return Licencia;
    }

    public void setLicencia(int Licencia) {
        this.Licencia = Licencia;
    }
    
}
