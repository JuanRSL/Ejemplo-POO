package com.mycompany.transporte;

public class Transporte {

    public static void main(String[] args) {
        
        System.out.println("Integrantes\n Miguel Angel Quintin Acero\n Juan Esteban Rodriguez Salazar");
        
        //Conductores
        Conductor ConducA = new Conductor("Chayanne Arce", 156, 045);
        Conductor ConducB = new Conductor("Maluma Baby", 26, 420);

        //Especifica los pasajeros
        Pasajero uno = new Pasajero("Donald Trump", 892, "L" ,3);
        Pasajero dos = new Pasajero("Gustavo Petro", 412, "K" ,4);
        Pasajero tres = new Pasajero("Karol G", 712, "F" ,9);
        Pasajero cuatro = new Pasajero("Ernesto Perez", 994, "Q" ,4);
        Pasajero cinco = new Pasajero("Vicente Fernandez", 475, "G" ,1);
        
        //Diseño de la ruta
        Ruta rutaA = new Ruta("Chapinero", "Las Americas", 12.00, 01.30);
        Ruta rutaB = new Ruta("Terminal El Salitre", "Terminal de Medellin", 15.00, 23.00);
        
        //Asignación de vehiculos
        Vehiculo Transmilenio = new Vehiculo("KJU-265", "Mercedes Benz", 50);
        Vehiculo Bus = new Vehiculo ("LÑO-897", "Chevrolet", 32);  //Placa, Marca del vehiculo, Capacidad.
        
        //Asignación de pasajeros
        Pasajero[] pasajeroUno = {uno, tres, cinco};
        Pasajero[] pasajeroDos = {dos, cuatro};
        
        //Mostrar Info viaje 1.
        System.out.println("      INFORMACIÓN DE LA RUTA      ");
        System.out.println("Origen: " + rutaA.getOrigen());
        System.out.println("Destino: " + rutaA.getDestino());
        System.out.println("Hora de inicio: " + rutaA.getHoraInicio());
        System.out.println("Hora de llegada: " + rutaA.getHoraLlegada());

        System.out.println("\n      INFORMACIÓN DEL VEHÍCULO      ");
        System.out.println("Placa: " + Transmilenio.getPlaca());
        System.out.println("Modelo: " + Transmilenio.getModelo());
        System.out.println("Capacidad: " + Transmilenio.getCapacidad());

        System.out.println("\n       CONDUCTOR       ");
        System.out.println("Nombre: " + ConducA.getNombres());
        System.out.println("ID: " + ConducA.getID());
        System.out.println("Licencia: " + ConducA.getLicencia());

        System.out.println("\n       PASAJEROS       ");
        for (Pasajero p : pasajeroUno) {
            System.out.println("Nombre: " + p.getNombres() + " | ID: " + p.getID() + " | Boleto: " + p.getBoleto() + p.getNumeroBoleto());
        }
        
        //Mostrar info Viaje 2.
        System.out.println("\n\n\n      INFORMACIÓN DE LA RUTA 2    ");
        System.out.println("Origen: " + rutaB.getOrigen());
        System.out.println("Destino: " + rutaB.getDestino());
        System.out.println("Hora de inicio: " + rutaB.getHoraInicio());
        System.out.println("Hora de llegada: " + rutaB.getHoraLlegada());

        System.out.println("\n      INFORMACIÓN DEL VEHÍCULO      ");
        System.out.println("Placa: " + Bus.getPlaca());
        System.out.println("Modelo: " + Bus.getModelo());
        System.out.println("Capacidad: " + Bus.getCapacidad());

        System.out.println("\n       CONDUCTOR       ");
        System.out.println("Nombre: " + ConducB.getNombres());
        System.out.println("ID: " + ConducB.getID());
        System.out.println("Licencia: " + ConducB.getLicencia());

        System.out.println("\n       PASAJEROS       ");
        for (Pasajero p : pasajeroDos) {
            System.out.println("Nombre: " + p.getNombres() + " | ID: " + p.getID() + " | Boleto: " + p.getBoleto() + p.getNumeroBoleto());
        }
    }
}
